document.addEventListener('DOMContentLoaded', function () {
    var palla = document.getElementById('palla');
    var immaginesx = document.getElementById('immaginesx');
    var immaginedx = document.getElementById('immaginedx');
    var score = document.getElementById('score');
    var countdown = document.getElementById('countdown');
    var restart = document.getElementById('restart');
    var pausa = document.getElementById('pausa');
    var play = document.getElementById('play');
    var nameInputs = document.getElementById('nameInputs');
    var player1NameInput = document.getElementById('player1Name');
    var player2NameInput = document.getElementById('player2Name');
    var startButton = document.getElementById('startButton');
    var vittoria = document.getElementById('vittoria');
    var x = 50;
    var y = 50;
    var initialVelocitaX = 1;
    var initialVelocitaY = 0.5;
    var velocitaX = initialVelocitaX;
    var velocitaY = initialVelocitaY;
    var velocitaRacchetta = 2;
    var keysPressed = {};
    var player1Score = 0;
    var player2Score = 0;
    var player1Name = 'GIOCATORE 1';
    var player2Name = 'GIOCATORE 2';
    var gameInterval, moveBallInterval;

    // Load audio files
    var popSound = new Audio('./Suono/pop.mp3');
    var applauseSound = new Audio('./Suono/applauso.mp3');
    var victorySound = new Audio('./Suono/vittoria.mp3'); // Load victory sound

    function updateScore() {
        score.innerHTML = player1Name + ': ' + player1Score + ' - ' + player2Name + ': ' + player2Score;
    }

    function checkVictory() {
        if (player1Score >= 5 || player2Score >= 10) {
            clearInterval(gameInterval);
            clearInterval(moveBallInterval);
            victorySound.play();
            vittoria.style.display = 'block'; // Show victory image
            alert('Vittoria!');
            return true;
        }
        return false;
    }

    function Muovi() {
        if (keysPressed['87']) { // W
            if (parseFloat(immaginesx.style.top) - velocitaRacchetta >= 0) {
                immaginesx.style.top = (parseFloat(immaginesx.style.top) - velocitaRacchetta) + "%";
            }
        }
        if (keysPressed['83']) { // S
            if (parseFloat(immaginesx.style.top) + velocitaRacchetta <= 100) {
                immaginesx.style.top = (parseFloat(immaginesx.style.top) + velocitaRacchetta) + "%";
            }
        }
        if (keysPressed['38']) { // Up arrow
            if (parseFloat(immaginedx.style.top) - velocitaRacchetta >= 0) {
                immaginedx.style.top = (parseFloat(immaginedx.style.top) - velocitaRacchetta) + "%";
            }
        }
        if (keysPressed['40']) { // Down arrow
            if (parseFloat(immaginedx.style.top) + velocitaRacchetta <= 100) {
                immaginedx.style.top = (parseFloat(immaginedx.style.top) + velocitaRacchetta) + "%";
            }
        }
    }

    function moveBall() {
        x += velocitaX;
        y += velocitaY;

        if (x <= 0) {
            player2Score++;
            updateScore();
            applauseSound.play();
            alert(player2Name + ' ha segnato!');
            if (!checkVictory()) {
                resetGame();
            }
        }
        if (x >= 100) {
            player1Score++;
            updateScore();
            applauseSound.play();
            alert(player1Name + ' ha segnato!');
            if (!checkVictory()) {
                resetGame();
            }
        }
        if (y >= 100 || y <= 0) {
            velocitaY = -velocitaY;
        }

        var pallaRect = palla.getBoundingClientRect();
        var immagineDxRect = immaginedx.getBoundingClientRect();
        var immagineSxRect = immaginesx.getBoundingClientRect();
        if (pallaRect.right >= immagineDxRect.left && pallaRect.left <= immagineDxRect.right && pallaRect.bottom >= immagineDxRect.top && pallaRect.top <= immagineDxRect.bottom) {
            velocitaX = -Math.abs(velocitaX);
            popSound.play();
        }
        if (pallaRect.left <= immagineSxRect.right && pallaRect.right >= immagineSxRect.left && pallaRect.bottom >= immagineSxRect.top && pallaRect.top <= immagineSxRect.bottom) {
            velocitaX = Math.abs(velocitaX);
            popSound.play();
        }

        palla.style.left = x + '%';
        palla.style.top = y + '%';
    }

    function resetGame() {
        clearInterval(gameInterval);
        clearInterval(moveBallInterval);
        x = 50;
        y = 50;
        immaginesx.style.top = '50%';
        immaginedx.style.top = '50%';
        palla.style.left = '50%';
        palla.style.top = '50%';
        velocitaX = initialVelocitaX;
        velocitaY = initialVelocitaY;
        keysPressed = {};
        countdownStart(3);
    }

    function ripristinatutto() {
        window.location.reload();
    }

    function countdownStart(seconds) {
        countdown.innerHTML = seconds;
        countdown.style.display = 'block';
        var countdownInterval = setInterval(function () {
            seconds--;
            if (seconds > 0) {
                countdown.innerHTML = seconds;
            } else if (seconds === 0) {
                countdown.innerHTML = 'VIA!';
            } else {
                clearInterval(countdownInterval);
                countdown.style.display = 'none';
                gameInterval = setInterval(Muovi, 20);
                moveBallInterval = setInterval(moveBall, 20);
            }
        }, 1000);
    }

    document.addEventListener('keydown', function (e) {
        keysPressed[e.keyCode] = true;
    });

    document.addEventListener('keyup', function (e) {
        delete keysPressed[e.keyCode];
    });

    restart.addEventListener('click', ripristinatutto);

    pausa.addEventListener('click', function () {
        clearInterval(gameInterval);
        clearInterval(moveBallInterval);
        pausa.style.display = 'none';
        play.style.display = 'block';
    });

    play.addEventListener('click', function () {
        gameInterval = setInterval(Muovi, 20);
        moveBallInterval = setInterval(moveBall, 20);
        play.style.display = 'none';
        pausa.style.display = 'block';
    });

    startButton.addEventListener('click', function () {
        player1Name = player1NameInput.value || 'GIOCATORE 1';
        player2Name = player2NameInput.value || 'GIOCATORE 2';
        nameInputs.style.display = 'none';
        updateScore();
        countdownStart(3); // Start the initial countdown
    });

    updateScore();
});